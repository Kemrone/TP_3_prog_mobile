package com.example.listeplanetes;

import java.util.ArrayList;

public class Data {
    private ArrayList<Planete> planetes;

    public Data(){
        this.planetes = new ArrayList<Planete>();
    }


    public Planete get(int position){
        return this.planetes.get(position);
    }

    public int size(){
        return this.planetes.size();
    }

    public void installePlanetes() {

       this.planetes.add(new Planete("Mercure",null));
       this.planetes.add(new Planete("Venus",null));
       this.planetes.add(new Planete("Terre",null));
       this.planetes.add(new Planete("Mars",null));
       this.planetes.add(new Planete("Jupiter",null));
       this.planetes.add(new Planete("Saturne",null));
       this.planetes.add(new Planete("Uranus",null));
       this.planetes.add(new Planete("Neptune",null));
       this.planetes.add(new Planete("Pluton",null));
    }


}
